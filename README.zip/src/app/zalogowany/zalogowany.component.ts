import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zalogowany',
  templateUrl: './zalogowany.component.html',
  styleUrls: ['./zalogowany.component.css']
})
export class ZalogowanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
