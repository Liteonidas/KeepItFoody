import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-skladniki-wyswietlanie',
  templateUrl: './skladniki-wyswietlanie.component.html',
  styleUrls: ['./skladniki-wyswietlanie.component.css']
})
export class SkladnikiWyswietlanieComponent implements OnInit, OnChanges {
  //let wynik: any = null;
  @Input() zapytanie: string = null;
  @Input() kategory: string = null;



  constructor(private httpclient: HttpClient){  }

  skladnik: Skladniki = null;
  skladniki: Skladniki[] = null;

  getPosts(): Observable<Skladniki> {
    return this.httpclient.get<Skladniki>('https://keepitfoody.pl/api/ingredient/read.php');
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(this.kategory);
    if(this.zapytanie != undefined){
      this.getPosts().subscribe(
        res => {
          this.skladniki = res['data'];
          this.skladniki = this.skladniki.filter(x => x.name.toUpperCase().includes(this.zapytanie.toUpperCase())).sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
          if(this.kategory != undefined){
            this.skladniki = this.skladniki.filter(x => x.category.toUpperCase().includes(this.kategory.toUpperCase())).sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0))
          }

        }
      );
    }else{
      this.getPosts().subscribe(
        res => {
          this.skladniki = res['data'].sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
          if(this.kategory != undefined){
            this.skladniki = this.skladniki.filter(x => x.category.toUpperCase().includes(this.kategory.toUpperCase())).sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
          }
        }
      );
    }
  }
  ngOnInit() {
    this.getPosts().subscribe(
      res => {
        this.skladniki = res['data'].sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
      },
      error => {
        console.log(error);
      }
      );
  }

  PrzygotujSkladnik(skladnik: Skladniki) {
    this.skladnik = skladnik;
  }

  FormatujWartosc(value: string) : string {
    return Number.parseFloat(value).toFixed(2);
  }
}
export interface Skladniki{
  ID?: number;
  name?: string;
  category?: string;
  energy?: number;
  protein?: number;
  carbohydrates?: number;
  fats?: number;
  fibre?: number;
  salt?: number;
  description?: string;
  gluten?: number;
  lactose?: number;

}
