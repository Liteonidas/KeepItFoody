import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-profil-dane-szczegolowe',
  templateUrl: './profil-dane-szczegolowe.component.html',
  styleUrls: ['./profil-dane-szczegolowe.component.css']
})
export class ProfilDaneSzczegoloweComponent implements OnInit {

  options: any[] = [ 
    { key: 'K', name: 'Kobieta'},
    { key: 'M', name: 'Mężczyzna'},
    { key: 'N', name: 'Nie podano'},
  ];
  selectedSex;
  selectedLifestyle;
  Kwspolczynniki = [1.2, 1.3, 1.5, 1.6, 1.9, 2.2];
  Mwspolczynniki = [1.2, 1.3, 1.6, 1.7, 2.1, 2.4];
  czyWszystkieDaneWypelnione: boolean = false;

  @Input() model: any;
    message: any = null;

  constructor(private httpclient: HttpClient) { }
  
  public form: FormGroup;

  ngOnInit() {
    this.form = new FormGroup({
      height : new FormControl(this.model.height != "null" && this.model.height !== "undefined" ? parseFloat(this.model.height).toFixed(2) : ''),
      weight : new FormControl(this.model.weight != "null" && this.model.weight !== "undefined" ? parseFloat(this.model.weight).toFixed(2) : ''),
      lifestyle : new FormControl(this.model.lifestyle != "null" && this.model.lifestyle !== "undefined" ? this.model.lifestyle : ''),
      bmr: new FormControl('')
    });

    this.selectedSex = this.model.sex != null ? this.options.find(x => x.key == this.model.sex) :this.options[2];
    this.selectedLifestyle = this.model.lifestyle;
    this.options = this.options.filter(x => x.key != this.selectedSex.key);

    this.obliczBMR();

    this.form.get('height').valueChanges.subscribe(val => {
      if (!this.czyWszystkieDaneWypelnione)
        this.obliczBMR();
    });

    this.form.get('weight').valueChanges.subscribe(val => {
      if (!this.czyWszystkieDaneWypelnione)
        this.obliczBMR();
    });

    this.CzyWszystkieDaneWypelnione();
  }

  CzyWszystkieDaneWypelnione() {
    this.form.valueChanges.subscribe(x => {
      this.czyWszystkieDaneWypelnione = x.weight == null || x.height == null || x.lifestyle == null;
    });
  }

  ZapisDanych(){
    let model = new ZapisDanychModel();
    model.height =  this.model.height;
    model.new_height = Number.isInteger(this.form.controls.height.value) ? this.form.controls.height.value + 0.00001 : this.form.controls.height.value;
    model.weight =  this.model.weight;
    model.new_weight =   Number.isInteger(this.form.controls.weight.value) ? this.form.controls.weight.value + 0.00001 : this.form.controls.weight.value;
    model.email = this.model.email; //bo inaczej nie dziala
    model.name = this.model.name;
    model.date_birth = this.model.date_birth;
    model.sex = localStorage.getItem('sex');
    model.lifestyle = this.selectedLifestyle;

    this.httpclient.put('https://keepitfoody.pl/api/user/update.php', model, { headers: new HttpHeaders({  'Content-Type': 'application/hal+json'  })}).subscribe(
      result =>{
      //  console.log(result);
       // console.log(model);
        this.message = result['Message'];
        localStorage.setItem('height', model.new_height.toString());
        localStorage.setItem('weight', model.new_weight.toString());
        // localStorage.setItem('sex', model.new_sex);
        // localStorage.setItem('lifestyle', model.new_lifestyle);

        this.obliczBMR();
      },
      error =>{
        this.message = error.error;
      },
    );
  }

  sexWasChange(sex) {
    localStorage.setItem('sex', sex);
  }

  lifestyleWasChange(lifestyle) {
    this.selectedLifestyle = lifestyle;
  }

  obliczBMR() {
    let bmr = null;
    if (this.form.controls.weight.value !== '' || this.form.controls.height.value !== '') {
      if (localStorage.getItem('sex') === 'K') {
        bmr = 655 + (9.6 * this.form.controls.weight.value) + (1.8 * this.form.controls.height.value) - (4.7 * this.wiek());
      }
      else if (localStorage.getItem('sex') === 'M') {  
        bmr = 66 + 13.7 * this.form.controls.weight.value + 5 * this.form.controls.height.value - 6.76 * this.wiek();
      }
    }
    this.form.controls.bmr.patchValue(bmr == null ? '' : bmr.toFixed(2));
  }

  wiek() {
    let now = new Date();
    let birth = new Date(this.model.date_birth);
    return now.getFullYear() - birth.getFullYear();
  }
}

export class ZapisDanychModel{
  email: string;
  date_birth: string;
  name: string;
  height: number; 
  new_height: number;
  weight: number;
  new_weight: number;
  sex: string;
  new_sex: number;
  lifestyle: number;
  new_lifestyle: string;
  //alergeny: ; 
  bmr: number;
}
