import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Skladniki } from '../skladniki-wyswietlanie/skladniki-wyswietlanie.component';

@Component({
  selector: 'app-przepisy-wyswietlanie',
  templateUrl: './przepisy-wyswietlanie.component.html',
  styleUrls: ['./przepisy-wyswietlanie.component.css']
})
export class PrzepisyWyswietlanieComponent implements OnInit, OnChanges {

  @Input() szukajp: string = null;

  closeResult: string;

  constructor(private modalService: NgbModal,
              private httpclient: HttpClient) { }

  przepisy: Przepis[] = null;
  przepis:  Przepis = null;

  getPosts(): Observable<Array<Przepis>> {
    return this.httpclient.get<Array<Przepis>>('https://keepitfoody.pl/api/recipe/read.php');
  }

  ngOnChanges(changes: SimpleChanges): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    if (this.szukajp != undefined) {
      this.getPosts().subscribe(
        res => {
          console.log(res);
          this.przepisy = res['data'];
          this.przepisy = this.przepisy.filter(x => x.recipe_name.toUpperCase().includes(this.szukajp.toUpperCase())).sort((a,b) => (a.recipe_name > b.recipe_name) ? 1 : ((b.recipe_name > a.recipe_name) ? -1 : 0));
        }
      );
    } else {
      this.getPosts().subscribe(
        res => {
          this.przepisy = res['data'].sort((a,b) => (a.recipe_name > b.recipe_name) ? 1 : ((b.recipe_name > a.recipe_name) ? -1 : 0));
        }
      );
    }
  }
  ngOnInit() {
    this.getPosts().subscribe(
      res => {
        console.log(res);
        this.przepisy = res['data'].sort((a,b) => (a.recipe_name > b.recipe_name) ? 1 : ((b.recipe_name > a.recipe_name) ? -1 : 0));
      },
      error => {
        console.log(error);
      }
    );
  }

  open(content, przepis) {
    this.przepis = przepis;
    // 1. Bierzesz id z przepis
    // 2. Strzelasz do  API z pkt. c
    // 3. To co dostajesz przypisujesz do this.przepis
    this.httpclient.get<Array<Skladniki>>('https://keepitfoody.pl/api/recipe/read.php?id_recipe=' + Number.parseInt(przepis.id_recipe)).subscribe(res =>  {
      this.przepis.skladniki = res['data'];
    })
    console.log(this.przepis);
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title', size: 'lg'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      console.log(content);
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

}
export class Przepis{
  id_recipe: string;
  recipe_name: string;
  prepare: string;
  recipe_photo: string;
  preparing_time: string;
  difficulty: string;
  id_user: string;
  user_photo: string;
  first_name: string;

  skladniki: Array<Skladniki>;
}