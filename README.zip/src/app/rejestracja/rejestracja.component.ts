import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { FacebookLoginProvider, GoogleLoginProvider, AuthService } from 'angular5-social-login';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-rejestracja',
  templateUrl: './rejestracja.component.html',
  styleUrls: ['./rejestracja.component.css']
})
export class RejestracjaComponent implements OnInit {
  @ViewChild('content') content;

  constructor(private httpclient: HttpClient, private router: Router, private socialAuthService: AuthService, private modalService: NgbModal) { }


  public form: FormGroup;
  czyAktywny: boolean = false;
  czyZarejestrowano: boolean = null;
  message: string = '';

  zmienAktywnosc() {
    this.czyAktywny = !this.czyAktywny;
  }

  rejestracja(){
    let uzytkownik = new Uzytkownik();
   
    uzytkownik.email=this.form.controls.email.value;
    uzytkownik.name=this.form.controls.name.value;
    uzytkownik.pass=this.form.controls.pass.value;
    uzytkownik.pass2=this.form.controls.pass2.value;

    this.httpclient.post('https://keepitfoody.pl/api/user/register.php', uzytkownik, { headers: new HttpHeaders({  'Content-Type': 'application/hal+json'  })}).subscribe(
      result => {
        console.log(result);
        if(result["Message"] != "Błąd walidacji"){
        this.czyZarejestrowano = true;
        this.modalService.open(this.content, { centered: true });
        this.form.reset();
      }else {
        this.czyZarejestrowano = false;
        this.message = "Brak wymaganych danych!";
      }
      },
      error => {
        this.czyZarejestrowano = false;
        this.message = error.error;
        
      },
      () => {
        // ...
      }
    );
  }
  logowaniePrzezSocialMedia(isFacebook: boolean = false) {
    let socialPlatformProvider = isFacebook ? FacebookLoginProvider.PROVIDER_ID : GoogleLoginProvider.PROVIDER_ID;
    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        if (isFacebook == true) {
          let model = {};
          model['email'] = userData.email;
          model['first_name'] = userData.name.split(' ')[0];
          this.httpclient.post('https://keepitfoody.pl/api/user/fbgmail.php', model).subscribe(result => {
            localStorage.setItem('token', result['token']);
            localStorage.setItem('id', result['id']);
            localStorage.setItem('name', result['name']);
            localStorage.setItem('email', result['email']);
            localStorage.setItem('date_birth', result['date_birth']);
            this.router.navigate(['/kalendarz/' + new Date()]);
          },
            err => {
              this.czyZarejestrowano = false;
              this.message = 'Błędne dane logowania';
              console.log(err);
            });
        }

        console.log('logowaniePrzezSocialMedia', userData);
      });
  }

  
  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl(), 
      email: new FormControl('', Validators.email), 
      pass: new FormControl('', [Validators.required, PasswordValidation.strong]), 
      pass2: new FormControl('')
    },
    {
      validators: PasswordValidation.MatchPassword
    });
  }

  
}
export class Uzytkownik{
      public name: string;
      public email: string;
      public pass: string; 
      public pass2: string;      
}

export class PasswordValidation {
  static strong(control: FormControl) {
    let hasNumber = /\d/.test(control.value);
    let hasUpper = /[A-Z]/.test(control.value);
    let hasLower = /[a-z]/.test(control.value);
    // console.log('Num, Upp, Low', hasNumber, hasUpper, hasLower);
    const valid = hasNumber && hasUpper && hasLower;
    if (!valid) {
        // return what´s not valid
        return { strong: true };
    }
    return null;
}
static MatchPassword(AC: AbstractControl) {
  let password = AC.get('pass').value; // to get value in input tag
  let confirmPassword = AC.get('pass2').value; // to get value in input tag
  if(password != confirmPassword && password != '' && confirmPassword != '') {
    AC.get('pass2').setErrors( {MatchPassword: true} )
  } else {
      return null
  }
  
}
}