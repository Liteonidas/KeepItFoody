import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService, FacebookLoginProvider, GoogleLoginProvider } from 'angular5-social-login';
import { applySourceSpanToStatementIfNeeded } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-logowanie',
  templateUrl: './logowanie.component.html',
  styleUrls: ['./logowanie.component.css']
})
export class LogowanieComponent implements OnInit {

  constructor(private httpclient: HttpClient, 
              private router: Router,
              private socialAuthService: AuthService) { }


  public form: FormGroup;
  czyZalogowano: boolean = null;
  message: string = null;

  ngOnInit() {
    this.form = new FormGroup({
      email: new FormControl('', Validators.email), 
      pass: new FormControl('', Validators.required), 
    });
  }

  logowanie() {
    let model = new LogowanieModel();

    model.email = this.form.controls.email.value;
    model.pass = this.form.controls.pass.value;

    this.httpclient.post('https://keepitfoody.pl/api/user/login.php', model, { headers: new HttpHeaders({  'Content-Type': 'application/hal+json'  })}).subscribe(
      result => {
        console.log(result);
       if (result['Message'] != 'Zalogowano!') {
        this.czyZalogowano = false;
        this.message = result['Message'];
       }
       else {
        localStorage.setItem('token', result['token']);
        localStorage.setItem('id', result['id']);
        localStorage.setItem('name', result['name']);
        localStorage.setItem('email', result['email']);
        localStorage.setItem('phone', result['phone']);
        localStorage.setItem('date_birth', result['date_birth']);
        localStorage.setItem('height', result['height']);
        localStorage.setItem('weight', result['weight']);
        localStorage.setItem('lifestyle', result['lifestyle']);
        localStorage.setItem('allergens', result['allergens']);
        localStorage.setItem('sex', result['sex']);
        localStorage.setItem('picture', result['picture']);
        this.czyZalogowano = true;
        this.router.navigate(['/kalendarz/' + new Date()]);
       }
       
      },
      error => {
        this.czyZalogowano = false;
        this.message = error.error;
      },
      () => {
        // ...
      }
    );
  }
  
  logowaniePrzezSocialMedia(isFacebook: boolean = false) {
    let socialPlatformProvider = isFacebook ? FacebookLoginProvider.PROVIDER_ID : GoogleLoginProvider.PROVIDER_ID;
    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        if (isFacebook == true) {
          let model = {};
          model['email'] = userData.email;
          model['first_name'] = userData.name.split(' ')[0];
          this.httpclient.post('https://keepitfoody.pl/api/user/fbgmail.php', model).subscribe(result => {
            localStorage.setItem('token', result['token']);
            localStorage.setItem('id', result['id']);
            localStorage.setItem('name', result['name']);
            localStorage.setItem('email', result['email']);
            localStorage.setItem('date_birth', result['date_birth']);
            this.router.navigate(['/kalendarz/' + new Date()]);
          },
            err => {
              this.message = 'Błędne dane logowania';
              console.log(err);
            });
        }

        console.log('logowaniePrzezSocialMedia', userData);
      });
  }
}
    
export class LogowanieModel {
  email: string;
  pass: string;
} 