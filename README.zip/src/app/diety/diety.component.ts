import { Component, OnInit } from '@angular/core';
//import {DziennikComponent} from '../dziennik';

@Component({
  selector: 'app-diety',
  templateUrl: './diety.component.html',
  styleUrls: ['./diety.component.css']
})
export class DietyComponent implements OnInit {

  premium: boolean = true;

  constructor() { }

  ngOnInit() {

  }

}


