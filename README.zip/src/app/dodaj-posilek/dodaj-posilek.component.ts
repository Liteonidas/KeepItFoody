import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dodaj-posilek',
  templateUrl: './dodaj-posilek.component.html',
  styleUrls: ['./dodaj-posilek.component.css']
})
export class DodajPosilekComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
