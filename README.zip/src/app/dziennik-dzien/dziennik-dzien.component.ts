import { Component, OnInit, EventEmitter, Output, Input, ViewChild, ChangeDetectorRef, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Przepis } from '../przepisy-wyswietlanie/przepisy-wyswietlanie.component';
import { Skladniki } from '../skladniki-wyswietlanie/skladniki-wyswietlanie.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dziennik-dzien',
  templateUrl: './dziennik-dzien.component.html',
  styleUrls: ['./dziennik-dzien.component.css'],
})
export class DziennikDzienComponent implements OnInit, OnChanges {

  @Input() date: Date = null;
  @Output() obecnaData: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild("plan") plan;
  @ViewChild("realizacja") realizacja;

  constructor(private httpClient: HttpClient, private changeDetector: ChangeDetectorRef, private modalService: NgbModal) {

  }

  bmr: number = null;
  water: number = null;
  realizacjaProcent: number = null;
  planProcent: number = null;
  realizacjaTytul: string = '';
  reallizacajaPodtytul: string = '';
  formGroup: FormGroup = null;
  czas = { hour: 0, minute: 0 };;
  message: string = null;
  dodajAktywne: boolean = false;
  posilki: any[] = null;
  wszystkiePrzepisy: Przepis[] = null;
  przefiltrowanePrzepisy: Przepis[] = null;
  wybranyPrzepis: Przepis = null;
  WybranyPosilek: any = null;

  wszystkieSkladniki: Skladniki[] = null;
  przefiltrowaneSkladniki: Skladniki[] = null;
  wybraneSKladniki: { skladnik: Skladniki, quantity: number, number: number }[] = null;

  ngOnInit() {
    this.obliczBMR();
    this.obliczWode();
    this.realizacjaProcent = 80;
    this.planProcent = 50;
    this.changeDetector.markForCheck();

    this.formGroup = new FormGroup({
      nazwa: new FormControl('', Validators.required),
      szukajPrzepisu: new FormControl(''),
      gramatura: new FormControl(''),
      szukajSkladnika: new FormControl(''),
      quantity: new FormControl(''),
      number: new FormControl('')
    });


    this.pobierzListePrzepisow();
    this.pobierzListSkladnikow();
    this.pobierzPosiłki();
    this.obserwujZmianyWFormularzu();
  }
  open(content, posilek) {
    this.WybranyPosilek = posilek;
    if (this.WybranyPosilek.id_recipe != null) {
      this.httpClient.get('https://keepitfoody.pl/api/recipe/read.php?id_recipe=' + this.WybranyPosilek.id_recipe).subscribe(res => {
        this.WybranyPosilek['ingredients'] = res['data'];
        console.log(this.WybranyPosilek);
      });
    }
    else {
      this.httpClient.get('https://keepitfoody.pl/api/user/read-meals.php?who=' + localStorage.getItem('id') + '&fk_ing=' + this.WybranyPosilek.id_meal).subscribe(res => {
        this.WybranyPosilek['ingredients'] = res['data'];
        console.log(this.WybranyPosilek);
      });
    }
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      // this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  obliczBMR() {
    let weight = localStorage.getItem('weight');
    let height = localStorage.getItem('height');
    let date_birth = localStorage.getItem('date_birth');
    if (weight !== '' || height !== '') {
      if (localStorage.getItem('sex') === 'K') {
        this.bmr = 655 + (9.6 * parseFloat(weight)) + (1.8 * parseFloat(height)) - (4.7 * this.wiek(date_birth));
      }
      else if (localStorage.getItem('sex') === 'M') {
        this.bmr = 66 + 13.7 * parseFloat(weight) + 5 * parseFloat(height) - 6.76 * this.wiek(date_birth);
      }
    }
    this.bmr == null ? 0 : this.bmr;
    this.realizacjaTytul = this.bmr.toFixed(0) + ' kcal';
    this.changeDetector.markForCheck();
  }

  obliczWode() {
    if (this.bmr != null && this.bmr != undefined) {
      let wsp = localStorage.getItem('sex') === 'K' ? 1.2 : (localStorage.getItem('sex') === 'M' ? 1.31 : 0);
      this.water = (this.bmr * wsp) / 1000;
    }
    else this.water = 0;
    this.reallizacajaPodtytul = 'woda ' + this.water.toFixed(0) + ' L';
  }

  wiek(birth) {
    let now = new Date();
    let birthDate = new Date(birth);
    return now.getFullYear() - birthDate.getFullYear();
  }

  pobierzListePrzepisow() {
    this.httpClient.get<Array<Przepis>>('https://keepitfoody.pl/api/recipe/read.php').subscribe(result => {
      this.wszystkiePrzepisy = result['data'].sort((a, b) => (a.recipe_name > b.recipe_name) ? 1 : ((b.recipe_name > a.recipe_name) ? -1 : 0));
      console.log('przepisy', this.wszystkiePrzepisy)
      this.changeDetector.markForCheck();
    })
  }

  obserwujZmianyWFormularzu() {
    this.formGroup.valueChanges.subscribe(result => {
      if (result.szukajPrzepisu != '') {
        this.przefiltrowanePrzepisy = this.wszystkiePrzepisy.filter(x => x.recipe_name.toUpperCase().includes(result.szukajPrzepisu.toUpperCase()));
      }
      else {
        this.przefiltrowanePrzepisy = null;
      }

      if (![null, undefined, ''].includes(result.szukajSkladnika)) {
        this.przefiltrowaneSkladniki = this.wszystkieSkladniki.filter(x => x.name.toUpperCase().includes(result.szukajSkladnika.toUpperCase()));
      }
      else {
        this.przefiltrowaneSkladniki = null;
      }
      console.log('formChanges', result);
      this.changeDetector.markForCheck();
    })

  }

  pobierzListSkladnikow() {
    this.httpClient.get<Array<Skladniki>>('https://keepitfoody.pl/api/ingredient/read.php').subscribe(result => {
      this.wszystkieSkladniki = result['data'].sort((a, b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
      console.log('skladniki', this.wszystkieSkladniki)
      this.changeDetector.markForCheck();
    });
  }

  pobierzPosiłki() {
    this.httpClient.get('https://keepitfoody.pl/api/user/read-meals.php?who=' + localStorage.getItem('id')).subscribe(res => {
      this.posilki = res['data'] != null ? res['data'].filter(x => new Date(x.date).toDateString() == this.date.toDateString()) : null;
      console.log('posilki', this.posilki)
      this.changeDetector.markForCheck();
    });
  }

  WybierzPrzepis(przepis) {
    this.wybranyPrzepis = przepis;
    this.wybraneSKladniki = null;
    console.log(przepis);
  }

  WybierzSkladnik(skladnik) {
    if (this.wybraneSKladniki == null)
      this.wybraneSKladniki = [];
    this.wybraneSKladniki.push({
      skladnik: skladnik,
      quantity: this.formGroup.controls.quantity.value,
      number: this.formGroup.controls.number.value,
    });
    this.formGroup.controls.quantity.patchValue('');
    this.formGroup.controls.number.patchValue('');
    console.log(this.wybraneSKladniki);
  }

  usunSkladnik(skladnik) {
    this.wybraneSKladniki = this.wybraneSKladniki.filter(x => x != skladnik);
  }
  Zapisz() {
    if (!this.formGroup.valid && (this.wybranyPrzepis == null || this.wybraneSKladniki == null)) {
      this.message = "Nie wszystkie pola zostały wypełnione poprawnie!";
      console.log(this.message, this.formGroup.valid);
      return;
    }

    this.date.setHours(this.czas.hour, this.czas.minute);
    let model = {};
    if (this.wybranyPrzepis != null) {
      model = {
        who: localStorage.getItem('id'),
        meal_name: this.formGroup.controls.nazwa.value,
        date: this.date.getFullYear() + "-" +
          ("0" + (this.date.getMonth() + 1)).slice(-2) + "-" +
          ("0" + this.date.getDate()).slice(-2) + " " +
          ("0" + this.date.getHours()).slice(-2) + ":" +
          ("0" + this.date.getMinutes()).slice(-2) + ":00",
        recipe: this.wybranyPrzepis.id_recipe,
        status: 0
      };
    }
    else if (this.wybraneSKladniki != null) {
      model = {
        who: localStorage.getItem('id'),
        meal_name: this.formGroup.controls.nazwa.value,
        date: this.date.getFullYear() + "-" +
          ("0" + (this.date.getMonth() + 1)).slice(-2) + "-" +
          ("0" + this.date.getDate()).slice(-2) + " " +
          ("0" + this.date.getHours()).slice(-2) + ":" +
          ("0" + this.date.getMinutes()).slice(-2) + ":00",
        // id_ingredient: this.wybraneSKladniki.map(v => {
        //   return v.skladnik.ID;
        // }),
        // quantity: this.wybraneSKladniki.map(v => {
        //   return v.quantity;
        // }),
        // number: this.wybraneSKladniki.map(v => {
        //   return v.number;
        // }),
        status: 0
      };

      model['id_ingredient'] = new Object();
      model['quantity'] = new Object();
      model['number'] = new Object();
      for (let i = 0; i < this.wybraneSKladniki.length; i++) {
        model['id_ingredient'][(i + 1).toString()] = Number.parseInt(this.wybraneSKladniki[i].skladnik.ID.toString())
        model['quantity'][(i + 1).toString()] = this.wybraneSKladniki[i].quantity;
        model['number'][(i + 1).toString()] = this.wybraneSKladniki[i].number;
      }
    }

    this.httpClient.post('https://keepitfoody.pl/api/user/add-meal.php', model).subscribe(res => {
      this.message = res['Message'];
      this.pobierzPosiłki();
      console.log(this.message);
    },
      err => {
        console.log(err);
      });
    this.changeDetector.markForCheck();
  }

  FormatujCzas(date: Date) {
    return ("0" + date.getHours()).slice(2) + ':' + ("0" + date.getMinutes()).slice(2);
  }

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    if (changes['date'] != null && changes['date'] != undefined) {
      this.pobierzPosiłki();
    }
  }
}
