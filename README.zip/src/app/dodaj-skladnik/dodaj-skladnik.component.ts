import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-dodaj-skladnik',
  templateUrl: './dodaj-skladnik.component.html',
  styleUrls: ['./dodaj-skladnik.component.css']
})
export class DodajSkladnikComponent implements OnInit {

  public forms: FormGroup;
  public Message: string = null;
  //p: DodSkl;

  constructor(private http: HttpClient, private  router: Router) { }

  ngOnInit() {
    this.forms = new FormGroup({
      nazwa: new FormControl(),
      kategoria: new FormControl(),
      kalorycznosc: new FormControl(),
      bialka: new FormControl(),
      weglowodany: new FormControl(),
      tluszcze: new FormControl(),
      blonnik: new FormControl(),
      sole: new FormControl(),
      opis: new FormControl(),
      gluten: new FormControl(),
      laktoza: new FormControl()

    });
  }

  dodaj() {
    let skl = new DodSkl(); //Dlaczego jak był ustawiony interface, nie mogłem przypisać wartości poniższych, this.p.name = this.form...
    //console.log("coś");
    //skl.ID = 486;
    skl.name = this.forms.controls.nazwa.value;
    skl.category = this.forms.controls.kategoria.value;
    skl.energy = this.forms.controls.kalorycznosc.value + (Number.isInteger(this.forms.controls.kalorycznosc.value) ? 0.0001 : 0);
    skl.protein = this.forms.controls.bialka.value  + (Number.isInteger(this.forms.controls.bialka.value) ? 0.0001 : 0);
    skl.carbohydrates = this.forms.controls.weglowodany.value + (Number.isInteger(this.forms.controls.weglowodany.value) ? 0.0001 : 0);
    skl.fats = this.forms.controls.tluszcze.value  + (Number.isInteger(this.forms.controls.tluszcze.value) ? 0.0001 : 0);
    skl.fibre = this.forms.controls.blonnik.value  + (Number.isInteger(this.forms.controls.blonnik.value) ? 0.0001 : 0);
    skl.salt = this.forms.controls.sole.value  + (Number.isInteger(this.forms.controls.sole.value) ? 0.0001 : 0);
    skl.description = this.forms.controls.opis.value;
    if (this.forms.controls.gluten.value) {
      skl.gluten = 1;
    }
    else {
      skl.gluten = 0;
    }
    if (this.forms.controls.laktoza.value) {
      skl.lactose = 1;
    }
    else {
      skl.lactose = 0;
    }

    console.log(skl.salt);

    this.http.post('https://keepitfoody.pl/api/ingredient/add.php', skl, { headers: new HttpHeaders({ 'Content-Type': 'application/hal+json' }) }).subscribe(
      res => {
        console.log(res['Message']);
        this.Message = res['Message'];
      },
      error => {
        this.Message = error;
      }
    );

  }


}

export class DodSkl {
  ID?: number;
  name?: string;
  category?: string;
  energy?: number;
  protein?: number;
  carbohydrates?: number;
  fats?: number;
  fibre?: number;
  salt?: number;
  description?: string;
  gluten?: number;
  lactose?: number;

}
