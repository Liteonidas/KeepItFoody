import { Component, OnInit, Injectable } from '@angular/core';
import {
  ChangeDetectionStrategy,
  ViewChild,
  TemplateRef
} from '@angular/core';
import { Subject } from 'rxjs';
import { NgbModal, NgbDatepickerI18n } from '@ng-bootstrap/ng-bootstrap';
import {
  CalendarEvent,
  CalendarView,
  DAYS_OF_WEEK
} from 'angular-calendar';
import { CalendarDateFormatter, DateFormatterParams } from 'angular-calendar';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DziennikDzienComponent } from '../dziennik-dzien/dziennik-dzien.component';

const I18N_VALUES = {
  pl: {
    weekdays: ['Po', 'Wt', 'Śr', 'Cz', 'Pi', 'So', 'Nie'],
    months: ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpnień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'],
  },
};

// Define a service holding the language. You probably already have one if your app is i18ned.
@Injectable()
export class I18n {
  language = 'en';
}

// Define custom service providing the months and weekdays translations
@Injectable()
export class CustomDatepickerI18n extends NgbDatepickerI18n {
  getDayAriaLabel(date: import("@ng-bootstrap/ng-bootstrap").NgbDateStruct): string {
    return '';
  }

  constructor(private _i18n: I18n) {
    super();
  }

  getWeekdayShortName(weekday: number): string {
    return I18N_VALUES[this._i18n.language].weekdays[weekday - 1];
  }
  getMonthShortName(month: number): string {
    return I18N_VALUES[this._i18n.language].months[month - 1];
  }
  getMonthFullName(month: number): string {
    return this.getMonthShortName(month);
  }
}

export class CustomDateFormatter extends CalendarDateFormatter {
  // you can override any of the methods defined in the parent class

  public dayViewHour({ date, locale }: DateFormatterParams): string {
    return new DatePipe(locale).transform(date, 'HH:mm', locale);
  }

  public weekViewHour({ date, locale }: DateFormatterParams): string {
    return this.dayViewHour({ date, locale });
  }
}

@Component({
  selector: 'app-kalendarz',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './kalendarz.component.html',
  styleUrls: ['./kalendarz.component.css'],
  providers: [
    {
      provide: CalendarDateFormatter,
      useClass: CustomDateFormatter
    },
    I18n, 
    { 
      provide: NgbDatepickerI18n, 
      useClass: CustomDatepickerI18n
    }
  ]
})
export class KalendarzComponent implements OnInit {
  @ViewChild('dzien') dzien: DziennikDzienComponent;

  view: CalendarView = CalendarView.Month;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  model;

  modalData: {
    action: string;
    event: CalendarEvent;
  };

  refresh: Subject<any> = new Subject();
  viewS: Subject<CalendarView> = new Subject<CalendarView>();


  events: CalendarEvent[] = [
    
  ];
  locale: string = 'pl';

  weekStartsOn: number = DAYS_OF_WEEK.MONDAY;

  constructor(private _i18n: I18n, private route: ActivatedRoute) { 
    this._i18n.language = 'pl';
  }

  
  ngOnInit() {
    
    this.viewS.asObservable().subscribe(view => {
      this.view =  view;
    })
    
    this.fixNavigateToDay();

    this.route.params.subscribe(x => {
      if (x.date != null && x.date != undefined) {
        this.viewDate = new Date(x.date);
        this.setView(CalendarView.Day);
      } 
      else {
        this.viewDate = new Date();
        this.setView(CalendarView.Month);
      }
      this.model = {
        year: this.viewDate.getFullYear(),
        month: this.viewDate.getMonth(),
        day: ("0" +this.viewDate.getDate()).slice(-2) 
      }
    })
  }

  dayClicked(event): void {
    this.viewDate = event.day.date;
    this.viewS.next(CalendarView.Day);
  }

  setView(view: CalendarView) {
    this.viewS.next(view);
  }

  ZmienionoDzien(event) {
    this.viewDate = new Date(event.year + '-' + event.month + '-' + event.day);
    this.viewS.next(CalendarView.Day);
  }

  fixNavigateToDay() {
    setInterval(() => {
      // console.log(this.view, this.view === CalendarView.Day);
    },1000)
  }

}
