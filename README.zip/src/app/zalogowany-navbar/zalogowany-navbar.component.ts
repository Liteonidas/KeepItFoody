import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-zalogowany-navbar',
  templateUrl: './zalogowany-navbar.component.html',
  styleUrls: ['./zalogowany-navbar.component.css']
})
export class ZalogowanyNavbarComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  
  wyloguj(){
    // localStorage.removeItem('token');
    localStorage.clear();
    this.router.navigate(['/home']);
  }
}
