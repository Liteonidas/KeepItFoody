import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, EmailValidator } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profil-dane-podstawowe',
  templateUrl: './profil-dane-podstawowe.component.html',
  styleUrls: ['./profil-dane-podstawowe.component.css']
})
export class ProfilDanePodstawoweComponent implements OnInit {

  @Input() model: any;
  message: any = null;

  constructor(private httpclient: HttpClient, private router: Router) { }

    public form: FormGroup;


  ngOnInit() {
    console.log(this.model);
    this.form = new FormGroup({
      name : new FormControl(this.model.name != 'null' && this.model.name !== undefined ? this.model.name : '' ),
      date_birth : new FormControl(this.model.date_birth !== null && this.model.date_birth !== "undefined" ? this.model.date_birth : '' ),
      email : new FormControl(this.model.email !== null && this.model.email !== "undefined" ? this.model.email : ''),
    });
  }

  ZapisDanych(){
    let model = new ZapisDanychModel();
    model.name = this.model.name;
    model.new_name = this.form.controls.name.value;
    model.date_birth = this.model.date_birth;
    model.new_date_birth = this.form.controls.date_birth.value;
    model.email = this.form.controls.email.value;

    this.httpclient.put('https://keepitfoody.pl/api/user/update.php', model, { headers: new HttpHeaders({  'Content-Type': 'application/hal+json'  })}).subscribe(
    result =>{
      this.message = result['Message'];
      localStorage.setItem('name', model.new_name);
      localStorage.setItem('email', model.email);
      localStorage.setItem('date_birth', model.new_date_birth);
    },
    error =>{
      this.message = error.error;
    },
    () =>{
      //..
    }
    );

  }

  private PrepareDateStringForInputDate(date) {
    let newDate = new Date(date);
    let day = ("0" + newDate.getDate()).slice(-2);
    let month = ("0" + (newDate.getMonth() + 1)).slice(-2);
    return newDate.getFullYear() + "-" + (month) + "-" + (day);
  }
//   PrzekierujDoZmianaHasla(){
//     this.router.navigate(['\zmiana-hasla']);

// }


}
export class ZapisDanychModel{
  new_name: string;
  name: string;
  new_date_birth: string;
  date_birth: string;
  email:string;
}
