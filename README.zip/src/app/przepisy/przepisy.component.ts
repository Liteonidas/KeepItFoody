import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-przepisy',
  templateUrl: './przepisy.component.html',
  styleUrls: ['./przepisy.component.css']
})
export class PrzepisyComponent implements OnInit {

  public form: FormGroup;
  public szukaj: string;
  constructor(private httpclient: HttpClient) { }

  wyszukajPrzep(){
    this.szukaj = this.form.controls.szukaj.value;
    console.log(this.szukaj);
  }

  ngOnInit() {
    this.form = new FormGroup({
      szukaj: new FormControl()
    });
   
  }

}
