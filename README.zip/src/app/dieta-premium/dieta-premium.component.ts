import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dieta-premium',
  templateUrl: './dieta-premium.component.html',
  styleUrls: ['./dieta-premium.component.css']
})
export class DietaPremiumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
