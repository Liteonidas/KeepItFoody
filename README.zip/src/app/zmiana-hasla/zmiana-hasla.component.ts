import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-zmiana-hasla',
  templateUrl: './zmiana-hasla.component.html',
  styleUrls: ['./zmiana-hasla.component.css']
})
export class ZmianaHaslaComponent implements OnInit {

  constructor(private httpClient: HttpClient) {}

  public form: FormGroup;
  message: string = null;
  ngOnInit() {
    this.form = new FormGroup({
      old_pass: new FormControl('', Validators.required),
      new_pass: new FormControl('', Validators.required),
      new_pass2: new FormControl('', Validators.required),
    });
  }


  ZmienHaslo(){
    let model = new ZmianaHaslaModel();
    model.old_pass = this.form.controls.old_pass.value;
    model.new_pass = this.form.controls.new_pass.value;
    model.new_pass2 = this.form.controls.new_pass2.value;
    model.id = localStorage.getItem('id');

    this.httpClient.put('https://keepitfoody.pl/api/user/change-pass.php', model).subscribe(
      result=> {
        this.message = result['Message'];

      },
      error => {
        this.message = error.error;
      },
    
    )
  }
}

export class ZmianaHaslaModel{
  old_pass: string;
  new_pass: string;
  new_pass2: string;
  id: string;
}