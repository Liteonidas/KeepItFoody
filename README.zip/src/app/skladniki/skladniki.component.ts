import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-skladniki',
  templateUrl: './skladniki.component.html',
  styleUrls: ['./skladniki.component.css']
})
export class SkladnikiComponent implements OnInit {

  public formw: FormGroup;
  public szukaj: string;
  public kategoria: string;
  constructor() { }

  wyszukaj(){
    this.szukaj = this.formw.controls.szukaj.value;
    console.log(this.szukaj);
  }
  KategoriaChanged(kategoria){
    this.kategoria = kategoria === '' ? null : kategoria;
  }

  //let wynik = this.form.controls.wyszukaj.value;
  ngOnInit() {
    //console.log(wynik);
    this.formw = new FormGroup({
      szukaj: new FormControl()
    });
  }
}
