import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.css']
})
export class ProfilComponent implements OnInit {

  constructor(private httpclient: HttpClient, private router: Router) { }
  message:string = null;
  sciezkaZdjecia:string;
  model: any;


  ngOnInit() {
    this.model = {
      id:localStorage.getItem('id'),
      name:localStorage.getItem('name'),
      email:localStorage.getItem('email'),
      phone:localStorage.getItem('phone'),
      date_birth:localStorage.getItem('date_birth'),
      height:localStorage.getItem('height'),
      weight:localStorage.getItem('weight'),
      lifestyle:localStorage.getItem('lifestyle'),
      allergens:localStorage.getItem('allergens'),
      sex:localStorage.getItem('sex'),
      picture:localStorage.getItem('picture')
    };

    console.log(this.model);
    this.sciezkaZdjecia = this.model.picture == "null" ? 'http://ssl.gstatic.com/accounts/ui/avatar_2x.png' : 'https://keepitfoody.pl/api' + this.model.picture;
  }

  WyslijZdjecieNaSerwer(base64String) {
    let model = {
      picture: base64String,
      id: localStorage.getItem('id')
    };
    console.log(base64String);
    this.httpclient.put('https://keepitfoody.pl/api/user/photo.php', model).subscribe(
      result=>{
        this.message = result['Message'];
        this.sciezkaZdjecia = 'https://keepitfoody.pl/api/api/' + result['Ścieżka: '];
      },
      error => {
        this.message = error.error;
      }
    )
  }

  changeListener($event) : void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    var file:File = inputValue.files[0];
    var myReader:FileReader = new FileReader();

    myReader.onloadend = (e) => {
      let resultArray = (myReader.result as string).split(',');
      this.WyslijZdjecieNaSerwer(resultArray[resultArray.length - 1]);
    }
    myReader.readAsDataURL(file);
  }

  PrzekierujDoZmianaHasla(){
      this.router.navigate(['\zmiana-hasla']);

  }
}
