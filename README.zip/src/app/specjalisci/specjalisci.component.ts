import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specjalisci',
  templateUrl: './specjalisci.component.html',
  styleUrls: ['./specjalisci.component.css']
})
export class SpecjalisciComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
