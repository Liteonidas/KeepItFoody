import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wiadomosci',
  templateUrl: './wiadomosci.component.html',
  styleUrls: ['./wiadomosci.component.css']
})
export class WiadomosciComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
