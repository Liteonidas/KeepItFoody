import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profil-platnosci',
  templateUrl: './profil-platnosci.component.html',
  styleUrls: ['./profil-platnosci.component.css']
})
export class ProfilPlatnosciComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
